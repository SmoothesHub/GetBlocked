# Tests

The harness runs the mod source inside Unity 6000.2.9f1 with the real Unity engine and Harmony. `GameStubs.cs` supplies small stand-ins for Gorilla Tag and BepInEx APIs. No proprietary game source or game assemblies are included.

From the repository root on Windows:

```powershell
.\tests\run-tests.ps1 -GamePath 'D:\SteamLibrary\steamapps\common\Gorilla Tag' -UnityPath 'C:\Program Files\Unity\Hub\Editor\6000.2.9f1\Editor\Unity.exe'
```

The default paths can be used if both programs are installed in their standard locations. Unity must already be licensed on this machine. Its Package Manager needs the packages in `unity/Packages/manifest.json`, either cached locally or available to download on first import. Close this test project in the Editor before running the script.

`prepare-tests.ps1` copies the current mod source, test source, and four Harmony dependencies from your own BepInEx installation into the generated `unity/Assets` folder. It can also be run on its own. Edit the originals in `src` or `tests`; generated copies are overwritten on preparation. The DLL built for installation never includes the stubs or test runners.

The launcher runs two suites in separate Unity processes:

- `IntegrationTests.Run`: 34 checks for persistence, invalid data, native button dispatch, layout, both mute paths, unmute protection, cosmetics, holdables, pooled rigs, joining/leaving, loading, and restoration.
- `ClickRegressionLauncher.Run`: 18 play-mode checks for real physics trigger delivery with child hand colliders, debounce, native click dispatch, pointer events, the mouse callback, reused rows, and missing player references.

The mouse callback test invokes `OnMouseDown` with Unity `SendMessage`; it does not simulate an operating-system mouse click or validate a live camera raycast. The physics test does use actual Unity collision delivery. Voice tests exercise the state of stub speaker components and a real Unity AudioSource, not a live voice connection.

Results are written to `tests/unity-test-results.txt` and `tests/click-test-results.txt`. Full logs are `tests/unity-tests.log` and `tests/click-tests.log`. Each suite exits nonzero on failure, and the launcher enforces a ten-minute timeout per suite (adjustable with `-TimeoutSeconds`). Test state and generated files are ignored by Git.

The 1.0.1 source passed all 52 checks. These tests do not establish live-lobby compatibility. The separate `verify-api.ps1` checks compiled references and patch targets against the locally installed game; it also is not an in-game test.
