using System;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using LeaderboardBlock;

public static class IntegrationTests
{
    private static int checks;
    private static void Check(bool value, string message)
    {
        if (!value) throw new Exception("FAIL: " + message);
        checks++;
        Debug.Log("PASS: " + message);
    }
    private static void Invoke(object obj, string name)
    { obj.GetType().GetMethod(name, BindingFlags.NonPublic | BindingFlags.Instance).Invoke(obj, null); }

    public static void Run()
    {
        try
        {
            Directory.CreateDirectory(BepInEx.Paths.ConfigPath);
            string listFile = Path.Combine(BepInEx.Paths.ConfigPath, "persistence-test.txt");
            if (File.Exists(listFile)) File.Delete(listFile);
            var list = new BlockList(listFile);
            list.Load();
            list.Set("test-account-A", true);
            list.Set("test-account-A", true);
            var restart = new BlockList(listFile);
            restart.Load();
            Check(restart.Count == 1 && restart.Contains("test-account-A"), "persistent account IDs and duplicate protection");
            Check(!restart.Contains("test-account-B"), "different accounts are independent");
            restart.Set("test-account-A", false);
            list.Load();
            Check(!list.Contains("test-account-A"), "unblock survives reload");
            Check(!File.ReadAllText(listFile).Contains("test-account"), "saved file contains hashes only");
            string badFile = Path.Combine(BepInEx.Paths.ConfigPath, "corrupt-test.txt");
            File.WriteAllText(badFile, "bad header");
            bool rejected = false;
            try { new BlockList(badFile).Load(); } catch (InvalidDataException) { rejected = true; }
            Check(rejected && File.ReadAllText(badFile) == "bad header", "corrupt persistence is not silently overwritten");

            GorillaNetworking.GorillaComputer.instance = new GameObject("Computer").AddComponent<GorillaNetworking.GorillaComputer>();
            var pluginObject = new GameObject("Plugin");
            var plugin = pluginObject.AddComponent<Plugin>();
            if (!Plugin.Instance) Invoke(plugin, "Awake");
            Check(Plugin.Instance != null, "plugin starts with all Harmony patches");
            var player = new NetPlayer { UserId = "unity-test-account-A" };
            var other = new NetPlayer { UserId = "unity-test-account-B" };
            var local = new NetPlayer { UserId = "unity-test-local", IsLocal = true };
            RigContainer a = MakeRig(player), b = MakeRig(other), self = MakeRig(local);
            self.Rig.isOfflineVRRig = true;
            VRRigCache.Join(a); VRRigCache.Join(b); VRRigCache.Join(self);
            var row = MakeRow(player, true);
            var secondBoardRow = MakeRow(player, false);
            plugin.SyncRow(row); plugin.SyncRow(secondBoardRow);
            if (plugin.IsBlocked(player)) plugin.Toggle(row);
            for (int i = 0; i < 30; i++) { row.InitializeLine(); row.UpdateLine(); plugin.SyncRow(row); }
            Check(row.GetComponentsInChildren<BlockButton>(true).Length == 1, "refreshes do not duplicate BLOCK");
            var blockRow = row.GetComponent<BlockRow>();
            Vector3 mutePosition = row.muteButton.transform.localPosition;
            Check(blockRow.Button.transform.localPosition.x > -33.4f && blockRow.Button.transform.localPosition.x < mutePosition.x,
                "BLOCK sits between COLOR and MUTE");
            Check(Mathf.Approximately(mutePosition.x, 6.6f), "MUTE position is unchanged");
            Check(Mathf.Approximately(mutePosition.x - blockRow.Button.transform.localPosition.x, 12f * 1.15f),
                "BLOCK has the reference image's narrow gap beside MUTE");
            Check(blockRow.Button.GetComponent<MeshRenderer>().sharedMaterial == row.muteButton.offMaterial, "native unblocked material");
            Check(blockRow.Button.GetComponentInChildren<TextMeshPro>(true).text == "BLOCK", "separate TMP label is present");
            Renderer body = a.Rig.transform.Find("Body").GetComponent<Renderer>();
            Renderer disabled = a.Rig.transform.Find("Inactive cosmetic").GetComponent<Renderer>();
            Renderer alreadyHidden = a.Rig.transform.Find("Already hidden").GetComponent<Renderer>();
            blockRow.Button.Click();
            Check(plugin.IsBlocked(player), "native button dispatch blocks the target");
            Check(body.forceRenderingOff && disabled.forceRenderingOff, "body and inactive cosmetics are hidden");
            Check(!b.Rig.GetComponentInChildren<Renderer>().forceRenderingOff && !self.Rig.GetComponentInChildren<Renderer>().forceRenderingOff,
                "same-name other player and local player stay visible");
            Check(a.IsMutedFor(RigContainer.MuteReason.Manual) && !a.Voice.SpeakerInUse.enabled && a.ReplacementVoiceSource.mute,
                "native mute disables both voice paths");
            Check(row.muteButton.isOn && secondBoardRow.muteButton.isOn && blockRow.Button.isOn, "both boards update immediately");
            row.muteButton.Click();
            row.PressButton(false, GorillaPlayerLineButton.ButtonType.Mute);
            a.SetMuted(RigContainer.MuteReason.Manual, false);
            Check(row.muteButton.isOn && blockRow.Button.isOn && a.IsMutedFor(RigContainer.MuteReason.Manual), "all unmute paths are locked while blocked");

            GameObject hat = GameObject.CreatePrimitive(PrimitiveType.Cube);
            hat.transform.SetParent(a.Rig.transform);
            new GorillaNetworking.CosmeticItemRegistry().InitializeCosmetic(hat, false);
            Invoke(plugin, "BeforeRender");
            Check(hat.GetComponent<Renderer>().forceRenderingOff, "late-loaded cosmetic is hidden before render");
            var held = GameObject.CreatePrimitive(PrimitiveType.Cube);
            var item = held.AddComponent<TransferrableObject>();
            item.ownerRig = a.Rig;
            item.SetTargetRig(a.Rig);
            a.Rig.myBodyDockPositions.allObjects = new[] { item };
            Invoke(plugin, "BeforeRender");
            Check(held.GetComponent<Renderer>().forceRenderingOff, "detached holdable follows blocked owner");
            item.SetTargetRig(b.Rig);
            Invoke(plugin, "BeforeRender");
            Check(!held.GetComponent<Renderer>().forceRenderingOff, "holdable transferred to another player is restored");

            row.linePlayer = local;
            row.InitializeLine();
            Check(!blockRow.Button.gameObject.activeSelf, "reused local row cannot block yourself");
            row.linePlayer = player;
            row.InitializeLine();
            Check(blockRow.Button.gameObject.activeSelf && blockRow.Button.isOn, "reused row recovers the persistent block");
            VRRigCache.Leave(a);
            Check(!body.forceRenderingOff, "leaving releases renderer references and state");
            a.Rig.Creator = other;
            a.gameObject.SetActive(true);
            VRRigCache.Join(a);
            Invoke(plugin, "BeforeRender");
            Check(!body.forceRenderingOff, "pooled rig reused for another account stays visible");
            VRRigCache.Leave(a);
            a.Rig.Creator = player;
            a.gameObject.SetActive(true);
            VRRigCache.Join(a);
            Check(body.forceRenderingOff && a.IsMutedFor(RigContainer.MuteReason.Manual), "rejoining reapplies block and mute immediately");
            // This suite runs within one editor frame; the play-mode suite exercises real press timing.
            typeof(BlockButton).GetField("nextPressTime", BindingFlags.Instance | BindingFlags.NonPublic)
                .SetValue(blockRow.Button.GetComponent<BlockButton>(), float.NegativeInfinity);
            blockRow.Button.Click();
            Check(!body.forceRenderingOff && !hat.GetComponent<Renderer>().forceRenderingOff, "unblock restores body and new cosmetic");
            Check(!disabled.enabled && alreadyHidden.forceRenderingOff, "unblock preserves pre-existing hidden and disabled visuals");
            Check(!row.muteButton.isOn && !blockRow.Button.isOn && !a.IsMutedFor(RigContainer.MuteReason.Manual), "unblock resets both buttons and manual mute");
            Check(a.Voice.SpeakerInUse.enabled && !a.ReplacementVoiceSource.mute, "unblock restores voice output");

            var loading = MakeRig(new NetPlayer { UserId = "unity-test-loading" });
            loading.Voice.SpeakerInUse = null;
            var loadingRow = MakeRow(loading.Creator, false);
            VRRigCache.Join(loading);
            plugin.SyncRow(loadingRow);
            plugin.Toggle(loadingRow);
            Check(loading.IsMutedFor(RigContainer.MuteReason.Manual), "block handles partially initialized voice");
            plugin.Toggle(loadingRow);
            plugin.Toggle(row);
            Invoke(plugin, "Shutdown");
            Check(!body.forceRenderingOff, "shutdown restores renderer states");
            Check(Plugin.Instance == null, "shutdown removes static instance");
            var disk = new BlockList(Path.Combine(BepInEx.Paths.ConfigPath, "LeaderboardBlock", "blocked-players.txt"));
            disk.Load();
            Check(disk.Contains(player.UserId), "block remains saved after plugin shutdown");
            disk.Set(player.UserId, false);
            File.WriteAllText("../unity-test-results.txt", checks + " checks passed\n");
            EditorApplication.Exit(0);
        }
        catch (Exception error)
        {
            Debug.LogException(error);
            File.WriteAllText("../unity-test-results.txt", "FAILED after " + checks + " checks\n" + error);
            EditorApplication.Exit(1);
        }
    }

    private static RigContainer MakeRig(NetPlayer player)
    {
        var go = new GameObject(player.UserId);
        var rig = go.AddComponent<VRRig>(); rig.Creator = player;
        var container = go.AddComponent<RigContainer>(); container.Rig = rig;
        container.Voice = go.AddComponent<TestVoice>();
        container.Voice.SpeakerInUse = go.AddComponent<TestSpeaker>();
        container.ReplacementVoiceSource = go.AddComponent<AudioSource>();
        rig.myBodyDockPositions = go.AddComponent<BodyDockPositions>();
        foreach (string name in new[] { "Body", "Inactive cosmetic", "Already hidden", "Name tag" })
        {
            var visual = GameObject.CreatePrimitive(PrimitiveType.Cube);
            visual.name = name; visual.transform.SetParent(go.transform);
            if (name == "Inactive cosmetic") { visual.GetComponent<Renderer>().enabled = false; visual.SetActive(false); }
            if (name == "Already hidden") visual.GetComponent<Renderer>().forceRenderingOff = true;
            if (name == "Name tag") rig.nameTagAnchor = visual;
        }
        return container;
    }

    private static GorillaPlayerScoreboardLine MakeRow(NetPlayer player, bool tmp)
    {
        var go = new GameObject("Row", typeof(RectTransform));
        var row = go.AddComponent<GorillaPlayerScoreboardLine>(); row.linePlayer = player;
        var swatch = new GameObject("Color", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        swatch.transform.SetParent(go.transform); swatch.transform.localPosition = new Vector3(-33.4f, 0, 0);
        row.playerSwatch = swatch.GetComponent<Image>(); row.playerSwatch.rectTransform.sizeDelta = new Vector2(12, 12);
        var button = GameObject.CreatePrimitive(PrimitiveType.Cube);
        button.transform.SetParent(go.transform); button.transform.localPosition = new Vector3(6.6f, 0, 0); button.transform.localScale = Vector3.one * 12;
        row.muteButton = button.AddComponent<GorillaPlayerLineButton>(); row.muteButton.parentLine = row;
        var text = new GameObject("Mute Text", typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        text.transform.SetParent(button.transform); text.transform.localPosition = new Vector3(0, 0, -0.507f);
        row.muteButton.myText = text.GetComponent<Text>();
        row.muteButton.offMaterial = new Material(Shader.Find("Standard"));
        row.muteButton.onMaterial = new Material(Shader.Find("Standard")) { color = Color.red };
        row.muteButton.offText = "MUTE"; row.muteButton.onText = "MUTED";
        row.speakerIcon = new GameObject("Speaker").AddComponent<SpriteRenderer>();
        row.speakerIcon.transform.SetParent(go.transform); row.speakerIcon.transform.localPosition = new Vector3(-14.6f, 0, 0);
        if (tmp)
        {
            row.parentScoreboard = new GameObject("Board").AddComponent<GorillaScoreBoard>();
            row.parentScoreboard.buttonText = new GameObject("Button labels").AddComponent<TextMeshPro>();
            row.parentScoreboard.buttonText.fontSize = 4;
            row.parentScoreboard.buttonText.text = "MUTE          REPORT";
        }
        GorillaScoreboardTotalUpdater.allScoreboardLines.Add(row);
        return row;
    }
}
