[CmdletBinding()]
param(
    [string]$GamePath = $env:GTAG_PATH,
    [string]$UnityPath = 'C:\Program Files\Unity\Hub\Editor\6000.2.9f1\Editor\Unity.exe',
    [ValidateRange(30, 3600)][int]$TimeoutSeconds = 600
)

$ErrorActionPreference = 'Stop'
$UnityPath = (Resolve-Path -LiteralPath $UnityPath).Path
& (Join-Path $PSScriptRoot 'prepare-tests.ps1') -GamePath $GamePath
$project = Join-Path $PSScriptRoot 'unity'
$suites = @(
    @{ Method = 'IntegrationTests.Run'; Result = 'unity-test-results.txt'; Log = 'unity-tests.log' },
    @{ Method = 'ClickRegressionLauncher.Run'; Result = 'click-test-results.txt'; Log = 'click-tests.log' }
)
foreach ($suite in $suites) {
    $result = Join-Path $PSScriptRoot $suite.Result
    $log = Join-Path $PSScriptRoot $suite.Log
    if (Test-Path -LiteralPath $result) { Remove-Item -LiteralPath $result }
    $unityArgs = @(
        '-batchmode', '-nographics',
        '-projectPath', ('"' + $project + '"'),
        '-executeMethod', $suite.Method,
        '-logFile', ('"' + $log + '"')
    )
    Write-Output "Running $($suite.Method)..."
    $process = Start-Process -FilePath $UnityPath -ArgumentList $unityArgs -WorkingDirectory $project -WindowStyle Hidden -PassThru
    try {
        if (-not $process.WaitForExit($TimeoutSeconds * 1000)) {
            $process.Kill()
            throw "Unity timed out running $($suite.Method). See $log"
        }
        # The harness writes results and exits Unity itself; do not add -quit.
        if ($process.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $result)) {
            throw "Unity test failed (exit $($process.ExitCode)). See $log"
        }
        $text = Get-Content -LiteralPath $result -Raw
        if ($text -notmatch '^\d+ (?:play-mode input )?checks passed') {
            throw "Unexpected test result: $text. See $log"
        }
        Write-Output $text.Trim()
    }
    finally { $process.Dispose() }
}
