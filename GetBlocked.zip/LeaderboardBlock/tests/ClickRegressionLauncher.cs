using UnityEditor;
using UnityEngine;

public static class ClickRegressionLauncher
{
    public static void Run()
    {
        SessionState.SetBool("LeaderboardBlock.ClickTests", true);
        Attach();
        EditorApplication.EnterPlaymode();
    }

    [InitializeOnLoadMethod]
    private static void Attach()
    {
        if (!SessionState.GetBool("LeaderboardBlock.ClickTests", false)) return;
        EditorApplication.playModeStateChanged -= StateChanged;
        EditorApplication.playModeStateChanged += StateChanged;
        EditorApplication.update -= Poll;
        EditorApplication.update += Poll;
    }

    private static void StateChanged(PlayModeStateChange state)
    {
        if (state == PlayModeStateChange.EnteredPlayMode)
            new GameObject("Click regression runner").AddComponent<ClickRegressionRunner>();
    }

    private static void Poll()
    {
        if (!ClickRegressionRunner.Finished) return;
        SessionState.SetBool("LeaderboardBlock.ClickTests", false);
        EditorApplication.Exit(ClickRegressionRunner.ExitCode);
    }
}
