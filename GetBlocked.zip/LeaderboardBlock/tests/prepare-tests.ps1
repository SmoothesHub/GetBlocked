[CmdletBinding()]
param([string]$GamePath = $env:GTAG_PATH)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($GamePath)) {
    $GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag'
}
$core = Join-Path (Resolve-Path -LiteralPath $GamePath).Path 'BepInEx/core'
$dependencies = @('0Harmony.dll', 'MonoMod.RuntimeDetour.dll', 'MonoMod.Utils.dll', 'Mono.Cecil.dll')
foreach ($name in $dependencies) {
    if (-not (Test-Path -LiteralPath (Join-Path $core $name) -PathType Leaf)) {
        throw "Missing test dependency: $core/$name"
    }
}

$project = Join-Path $PSScriptRoot 'unity'
$runtime = Join-Path $project 'Assets/Runtime'
$editor = Join-Path $project 'Assets/Editor'
$plugins = Join-Path $project 'Assets/Plugins'
New-Item -ItemType Directory -Force -Path $runtime, $editor, $plugins | Out-Null
$source = Join-Path (Split-Path -Parent $PSScriptRoot) 'src'
foreach ($file in Get-ChildItem -LiteralPath $source -Filter '*.cs') {
    if ($file.Name -ne 'AssemblyInfo.cs') {
        Copy-Item -LiteralPath $file.FullName -Destination $runtime -Force
    }
}
foreach ($name in @('GameStubs.cs', 'ClickRegressionRunner.cs')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $runtime -Force
}
foreach ($name in @('IntegrationTests.cs', 'ClickRegressionLauncher.cs')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $editor -Force
}
foreach ($name in $dependencies) {
    Copy-Item -LiteralPath (Join-Path $core $name) -Destination $plugins -Force
}
Write-Output "Prepared Unity test project: $project"
