using System;
using System.Collections;
using System.IO;
using LeaderboardBlock;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class ClickRegressionRunner : MonoBehaviour
{
    public static bool Finished;
    public static int ExitCode;
    private int checks;

    private void Check(bool condition, string description)
    {
        if (!condition) throw new Exception("FAIL: " + description);
        checks++;
        Debug.Log("PASS: " + description);
    }

    private IEnumerator Start()
    {
        var test = RunChecks();
        while (true)
        {
            object wait;
            try
            {
                if (!test.MoveNext()) break;
                wait = test.Current;
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                Finish(1, "FAILED after " + checks + " checks\n" + error);
                yield break;
            }
            yield return wait;
        }
        Finish(0, checks + " play-mode input checks passed\n");
    }

    private void Finish(int result, string text)
    {
        File.WriteAllText(Path.GetFullPath("../click-test-results.txt"), text);
        ExitCode = result;
        Finished = true;
    }

    private IEnumerator RunChecks()
    {
        BepInEx.Paths.ConfigPath = Path.GetFullPath("../click-test-state");
        GorillaNetworking.GorillaComputer.instance = new GameObject("Computer").AddComponent<GorillaNetworking.GorillaComputer>();
        var plugin = new GameObject("Plugin").AddComponent<Plugin>();
        var target = MakeRig("physics-target");
        var other = MakeRig("other-target");
        VRRigCache.Join(target);
        VRRigCache.Join(other);
        var row = MakeRow(target.Creator);
        plugin.SyncRow(row);
        if (plugin.IsBlocked(target.Creator)) plugin.Toggle(row);
        var control = row.GetComponent<BlockRow>();
        var button = control.Button.GetComponent<BlockButton>();
        var collider = control.Button.GetComponent<BoxCollider>();
        var body = target.Rig.GetComponentInChildren<Renderer>();
        var otherBody = other.Rig.GetComponentInChildren<Renderer>();

        Check(collider.enabled && collider.isTrigger, "cloned collider is explicitly enabled for presses");
        Check(!control.Button.enabled && button.enabled, "BLOCK owns its callback; inherited MUTE trigger is disabled");
        Check(Mathf.Approximately(control.Button.transform.localPosition.x, -7.2f) &&
              control.Button.transform.localScale == Vector3.one * 12f, "existing position and size are unchanged");
        Check(button.Row == control && control.Line == row, "callback is bound to the live player row");

        var hand = new GameObject("Local hand indicator");
        hand.transform.position = new Vector3(-100, 0, 0);
        hand.AddComponent<GorillaTriggerColliderHandIndicator>().isLeftHand = true;
        var rb = hand.AddComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.useGravity = false;
        for (int i = 0; i < 2; i++)
        {
            var child = new GameObject("Hand collider " + i);
            child.transform.SetParent(hand.transform, false);
            child.AddComponent<SphereCollider>().radius = 0.1f;
        }
        yield return new WaitForFixedUpdate();
        hand.transform.position = control.Button.transform.position;
        yield return new WaitForFixedUpdate();
        yield return new WaitForFixedUpdate();
        Check(plugin.IsBlocked(target.Creator), "real physics collision reaches BLOCK with a parent hand indicator");
        Check(control.Button.isOn && control.Button.GetComponent<Renderer>().sharedMaterial == row.muteButton.onMaterial,
            "collision turns BLOCK red");
        Check(row.muteButton.isOn && target.IsMutedFor(RigContainer.MuteReason.Manual) &&
              !target.Voice.SpeakerInUse.enabled && target.ReplacementVoiceSource.mute, "collision enables native mute and red MUTE");
        Check(body.forceRenderingOff && !otherBody.forceRenderingOff, "collision hides only the selected player");
        control.Button.Click();
        Check(plugin.IsBlocked(target.Creator), "overlapping native click callback cannot toggle the same press back off");
        yield return new WaitForSeconds(0.65f);
        Check(plugin.IsBlocked(target.Creator), "holding two overlapping hand colliders does not repeat the press");
        row.muteButton.Click();
        Check(row.muteButton.isOn && target.IsMutedFor(RigContainer.MuteReason.Manual), "MUTE stays locked after a collider-driven block");

        hand.transform.position = new Vector3(-100, 0, 0);
        yield return new WaitForFixedUpdate();
        hand.transform.position = control.Button.transform.position;
        yield return new WaitForFixedUpdate();
        yield return new WaitForFixedUpdate();
        Check(!plugin.IsBlocked(target.Creator) && !control.Button.isOn && !row.muteButton.isOn,
            "a second physical press clears the same blocked state and both buttons");
        Check(!body.forceRenderingOff && target.Voice.SpeakerInUse.enabled && !target.ReplacementVoiceSource.mute,
            "second physical press restores original renderer and voice");
        hand.transform.position = new Vector3(-100, 0, 0);
        yield return new WaitForSeconds(0.35f);

        button.SendMessage("OnMouseDown", SendMessageOptions.RequireReceiver);
        var eventSystem = new GameObject("EventSystem").AddComponent<EventSystem>();
        var pointer = new PointerEventData(eventSystem) { button = PointerEventData.InputButton.Left };
        ExecuteEvents.Execute(control.Button.gameObject, pointer, ExecuteEvents.pointerClickHandler);
        Check(plugin.IsBlocked(target.Creator) && control.Button.isOn && body.forceRenderingOff,
            "mouse collider callback blocks once even when a pointer event also fires");
        yield return new WaitForSeconds(0.35f);
        ExecuteEvents.Execute(control.Button.gameObject, pointer, ExecuteEvents.pointerClickHandler);
        Check(!plugin.IsBlocked(target.Creator) && !body.forceRenderingOff && target.Voice.SpeakerInUse.enabled,
            "EventSystem pointer callback unblocks the same player");
        yield return new WaitForSeconds(0.35f);
        control.Button.GetComponent<IClickable>().Click();
        Check(plugin.IsBlocked(target.Creator) && body.forceRenderingOff && !target.Voice.SpeakerInUse.enabled,
            "native IClickable dispatcher also reaches all three effects");
        yield return new WaitForSeconds(0.35f);
        row.linePlayer = other.Creator;
        plugin.SyncRow(row);
        button.Click();
        Check(plugin.IsBlocked(other.Creator) && otherBody.forceRenderingOff && plugin.IsBlocked(target.Creator),
            "reused row resolves its new player instead of a stale cached player");
        yield return new WaitForSeconds(0.35f);
        row.linePlayer = null;
        button.Click();
        Check(plugin.IsBlocked(target.Creator) && plugin.IsBlocked(other.Creator), "missing player reference is rejected without changing either player");
        row.linePlayer = other.Creator;
        plugin.Toggle(row);
        row.linePlayer = target.Creator;
        plugin.Toggle(row);
        Destroy(hand);
        Destroy(plugin.gameObject);
        yield return null;
    }

    private static RigContainer MakeRig(string id)
    {
        var go = new GameObject(id);
        go.transform.position = new Vector3(100, 0, 0);
        var rig = go.AddComponent<VRRig>();
        rig.Creator = new NetPlayer { UserId = id, NickName = id };
        rig.myBodyDockPositions = go.AddComponent<BodyDockPositions>();
        var skin = GameObject.CreatePrimitive(PrimitiveType.Cube);
        skin.transform.SetParent(go.transform, false);
        var container = go.AddComponent<RigContainer>();
        container.Rig = rig;
        container.Voice = go.AddComponent<TestVoice>();
        container.Voice.SpeakerInUse = go.AddComponent<TestSpeaker>();
        container.ReplacementVoiceSource = go.AddComponent<AudioSource>();
        return container;
    }

    private static GorillaPlayerScoreboardLine MakeRow(NetPlayer player)
    {
        var row = new GameObject("Row", typeof(RectTransform)).AddComponent<GorillaPlayerScoreboardLine>();
        row.linePlayer = player;
        row.playerSwatch = new GameObject("Color", typeof(RectTransform), typeof(CanvasRenderer)).AddComponent<Image>();
        row.playerSwatch.transform.SetParent(row.transform, false);
        row.playerSwatch.transform.localPosition = new Vector3(-33.4f, 0, 0);
        row.playerSwatch.rectTransform.sizeDelta = new Vector2(12, 12);
        var native = GameObject.CreatePrimitive(PrimitiveType.Cube);
        native.transform.SetParent(row.transform, false);
        native.transform.localPosition = new Vector3(6.6f, 0, 0);
        native.transform.localScale = Vector3.one * 12;
        native.GetComponent<BoxCollider>().enabled = false;
        row.muteButton = native.AddComponent<GorillaPlayerLineButton>();
        row.muteButton.enabled = false;
        row.muteButton.parentLine = row;
        row.muteButton.myText = new GameObject("Mute Text", typeof(RectTransform), typeof(CanvasRenderer)).AddComponent<Text>();
        row.muteButton.myText.transform.SetParent(native.transform, false);
        row.muteButton.offMaterial = new Material(Shader.Find("Standard"));
        row.muteButton.onMaterial = new Material(Shader.Find("Standard")) { color = Color.red };
        row.muteButton.offText = "MUTE";
        row.muteButton.onText = "MUTED";
        GorillaScoreboardTotalUpdater.allScoreboardLines.Add(row);
        return row;
    }
}
