using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Runtime.CompilerServices;
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Assembly-CSharp-Editor")]

namespace BepInEx
{
    public class BepInPlugin : Attribute { public BepInPlugin(string id, string name, string version) {} }
    public class BaseUnityPlugin : MonoBehaviour { public Log Logger = new Log(); }
    public class Log { public void LogInfo(object msg) { Debug.Log(msg); } public void LogError(object msg) { Debug.LogError(msg); } }
    public static class Paths { public static string ConfigPath = System.IO.Path.GetFullPath("../test-state"); }
}
public class NetPlayer
{
    public bool IsNull;
    public bool IsLocal;
    public bool InRoom = true;
    public string UserId;
    public string NickName = "SAME NAME";
}
public class VRRig : MonoBehaviour
{
    public bool isOfflineVRRig, isMyPlayer;
    public NetPlayer Creator;
    public GameObject nameTagAnchor;
    public readonly List<GameObject> activeCosmetics = new List<GameObject>();
    public BodyDockPositions myBodyDockPositions;
    [MethodImpl(MethodImplOptions.NoInlining)] public void LocalUpdateCosmeticsWithTryon() {}
    [MethodImpl(MethodImplOptions.NoInlining)] public void SetCosmeticsActive(bool active) {}
    public void PlayHandTapLocal(int sound, bool left, float volume) {}
}
public class TestVoice : MonoBehaviour { public TestSpeaker SpeakerInUse; }
public class TestSpeaker : MonoBehaviour {}
public class RigContainer : MonoBehaviour
{
    [Flags] public enum MuteReason { None = 0, Manual = 1, Auto = 2, Room = 16 }
    private MuteReason muteReasons;
    public bool hasManualMute;
    public VRRig Rig;
    public TestVoice Voice;
    public AudioSource ReplacementVoiceSource;
    public NetPlayer Creator { get { return Rig.Creator; } }
    public bool IsMutedFor(MuteReason reasons) { return (muteReasons & reasons) != 0; }
    [MethodImpl(MethodImplOptions.NoInlining)] public void SetMuted(MuteReason reasons, bool muted)
    {
        muteReasons = muted ? muteReasons | reasons : muteReasons & ~reasons;
        RefreshVoiceChat();
    }
    [MethodImpl(MethodImplOptions.NoInlining)] public void RefreshVoiceChat()
    {
        if (!Voice) return;
        if (hasManualMute) muteReasons &= ~MuteReason.Auto;
        Voice.SpeakerInUse.enabled = muteReasons == MuteReason.None;
        ReplacementVoiceSource.mute = muteReasons != MuteReason.None;
    }
}
public static class VRRigCache
{
    public static List<RigContainer> ActiveRigContainers = new List<RigContainer>();
    public static event Action<RigContainer> OnRigActivated, OnRigDeactivated;
    public static event Action OnPostInitialize;
    public static void Join(RigContainer rig) { ActiveRigContainers.Add(rig); OnRigActivated?.Invoke(rig); }
    public static void Leave(RigContainer rig) { ActiveRigContainers.Remove(rig); rig.gameObject.SetActive(false); OnRigDeactivated?.Invoke(rig); }
    public static void Init() { OnPostInitialize?.Invoke(); }
}
public class GorillaPlayerScoreboardLine : MonoBehaviour
{
    public NetPlayer linePlayer;
    public GorillaPlayerLineButton muteButton;
    public Image playerSwatch;
    public SpriteRenderer speakerIcon;
    public GorillaScoreBoard parentScoreboard;
    private bool isMuteManual;
    private int mute;
    [MethodImpl(MethodImplOptions.NoInlining)] public void InitializeLine() { isMuteManual = false; mute = 0; }
    [MethodImpl(MethodImplOptions.NoInlining)] public void UpdateLine() { if (isMuteManual && mute == 1) muteButton.isOn = true; }
    [MethodImpl(MethodImplOptions.NoInlining)] public void ResetData() { linePlayer = null; }
    [MethodImpl(MethodImplOptions.NoInlining)] public void PressButton(bool isOn, GorillaPlayerLineButton.ButtonType buttonType)
    { if (buttonType == GorillaPlayerLineButton.ButtonType.Mute) { muteButton.isOn = isOn; mute = isOn ? 1 : 0; } }
}
public interface IClickable { void Click(bool leftHand = false); }
public class GorillaTriggerColliderHandIndicator : MonoBehaviour { public bool isLeftHand; }
public class GorillaPlayerLineButton : MonoBehaviour, IClickable
{
    public enum ButtonType { Mute, Report }
    public GorillaPlayerScoreboardLine parentLine;
    public ButtonType buttonType;
    public bool isOn, isAutoOn, testPress;
    public float touchTime, debounceTime;
    public Text myText;
    public string offText, onText, autoOnText;
    public Material onMaterial, offMaterial;
    [MethodImpl(MethodImplOptions.NoInlining)] public void Click(bool leftHand = false) { isOn = !isOn; parentLine.PressButton(isOn, buttonType); }
    public void UpdateColor() { GetComponent<MeshRenderer>().sharedMaterial = isOn ? onMaterial : offMaterial; myText.text = isOn ? onText : offText; }
}
public class GorillaScoreBoard : MonoBehaviour { public TextMeshPro buttonText; }
public static class GorillaScoreboardTotalUpdater { public static List<GorillaPlayerScoreboardLine> allScoreboardLines = new List<GorillaPlayerScoreboardLine>(); }
public class GorillaTagger : MonoBehaviour
{
    public static GorillaTagger Instance;
    public float tapHapticStrength, tapHapticDuration;
    public VRRig offlineVRRig;
    public void StartVibration(bool left, float strength, float duration) {}
}
public class TransferrableObject : MonoBehaviour
{
    public VRRig targetRig, ownerRig, myOnlineRig, myRig;
    public bool isSceneObject;
    [MethodImpl(MethodImplOptions.NoInlining)] public void SetTargetRig(VRRig rig) { targetRig = rig; }
    [MethodImpl(MethodImplOptions.NoInlining)] public void OnSpawn(VRRig rig) { ownerRig = rig; }
    [MethodImpl(MethodImplOptions.NoInlining)] public void OnDespawn() {}
}
public class BodyDockPositions : MonoBehaviour { public TransferrableObject[] allObjects; }
namespace GorillaNetworking
{
    public class CosmeticItemRegistry { [MethodImpl(MethodImplOptions.NoInlining)] public void InitializeCosmetic(GameObject obj, bool isOverride) {} }
    public class GorillaComputer : MonoBehaviour { public static GorillaComputer instance; }
}
