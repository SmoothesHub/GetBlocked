# Saved blocks

Version 1.0.1 has no configurable BepInEx `.cfg` settings. It creates its data file on the first successful block change:

```text
Gorilla Tag/BepInEx/config/LeaderboardBlock/blocked-players.txt
```

The actual location follows `BepInEx.Paths.ConfigPath` if the BepInEx configuration directory has been changed. No configuration file needs to be copied when installing the DLL.

`blocked-players.example.txt` is an empty, valid example. The first line is `LeaderboardBlock:1`. Each subsequent nonempty line is a lowercase, 64-character SHA-256 hash of a player's exact `NetPlayer.UserId`, encoded as UTF-8. Names and temporary actor numbers are not used. Entries are sorted when saved. These hashes identify accounts for this mod; they are not encryption.

Use the in-game BLOCK button to change the list. Saves use a temporary `.tmp` file and retain the previous list in `.bak` when replacing an existing file. A malformed list is left untouched and startup reports an error in the BepInEx log.

To move your blocks to another installation, close the game and copy your own `blocked-players.txt` to the same configuration folder. Do not replace an existing list with the empty example unless you intend to remove its saved blocks. The game also stores its native manual mute state separately in Unity PlayerPrefs.

Actual block lists, backups, temporary files, and test data are excluded from Git by `.gitignore`.
