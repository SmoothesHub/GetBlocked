# Leaderboard Block

A BepInEx 5 mod for the Windows PC version of Gorilla Tag. Adds a BLOCK button between COLOR and MUTE on the existing leaderboard.

Version **1.0.1** includes the button input fix: hand colliders, the native `IClickable` path, pointer clicks, and the mouse callback route through one debounced handler. The established button placement and size are preserved.

## Behavior

- Blocking turns BLOCK and MUTE red, applies the game's manual mute, and suppresses the selected remote player's body, name tag, cosmetics, and attached visuals locally.
- MUTE stays locked while BLOCK is active. Pressing BLOCK again restores the saved rendering states and clears the manual mute.
- Blocks are saved using hashes of stable player account IDs and reapplied when a player rejoins, including after restarting the game.
- Existing native materials, button geometry, and text styling are reused. The original COLOR, MUTE, and REPORT controls retain their positions.

Visual suppression uses cached renderer, canvas, and light references. Rig/cosmetic events refresh those references, with a half-second reconciliation of the game's cached rig and scoreboard lists. It does not disable player GameObjects or send block actions over the network. Other game-enforced voice restrictions can still keep a player muted after unblocking.

## Build

Requirements:

- Windows with a .NET SDK on PATH. The package was built with SDK 10.0.400; the SDK is used as a compiler, not as the game's runtime.
- A local Gorilla Tag installation containing `Gorilla Tag_Data/Managed`.
- BepInEx 5 installed in that game directory. The source was checked against BepInEx 5.4.23.5 and game assemblies using Unity 6000.2.9f1.

Run from the repository root:

```powershell
.\build.ps1 -GamePath 'D:\SteamLibrary\steamapps\common\Gorilla Tag'
```

Omit `-GamePath` for the standard Steam installation. Alternatively, set `GTAG_PATH` to your game directory. The project can also be built directly:

```powershell
dotnet build .\LeaderboardBlock.csproj -c Release "-p:GamePath=D:\SteamLibrary\steamapps\common\Gorilla Tag"
```

Output: `artifacts/LeaderboardBlock.dll`.

The project targets the .NET Framework 4.x API using the game's own Mono reference assemblies. `NuGet.Config` disables package feeds because no NuGet packages or downloaded reference packs are needed. Dependencies are resolved from your installation and are not copied to the output or included in this repository. Game updates can change these APIs.

Check the built DLL against your installed game:

```powershell
.\verify-api.ps1 -GamePath 'D:\SteamLibrary\steamapps\common\Gorilla Tag'
```

## Install

Close Gorilla Tag. Copy `artifacts/LeaderboardBlock.dll` into `Gorilla Tag/BepInEx/plugins/`, replacing an older copy, then start the game. Keep only one copy of the mod DLL installed.

Saved blocks are created automatically in `BepInEx/config/LeaderboardBlock/blocked-players.txt`. This version has no configurable `.cfg` settings. See [config/README.md](config/README.md) for the file format and empty example.

## Source layout

| File | Purpose |
| --- | --- |
| `src/Plugin.cs` | Plugin lifecycle, authoritative block decisions, native mute, and row/rig tracking |
| `src/BlockButton.cs` | Collider, pointer, mouse, and native click input with shared debounce |
| `src/BlockRow.cs` | Native button cloning, positioning, labels, and visual state |
| `src/BlockList.cs` | Persistent account-ID hashes and atomic file replacement |
| `src/VisibilityMask.cs` | Cached visual suppression, ownership checks, and original-state restoration |
| `src/Patches.cs` | Harmony hooks for rows, clicks, mute protection, cosmetics, and loading |
| `src/AssemblyInfo.cs` | Assembly metadata and version |

## Diagnostics and verification

The BepInEx log includes `BLOCK button pressed`, the target display name, mute and visibility steps, and a success or failure message. Invalid or unavailable rows are rejected with a diagnostic. Logging is enabled in this version; there is no logging setting.

The source passed 34 Unity integration-harness checks and 18 play-mode input checks. The harness uses real Unity and Harmony with game API test doubles; see [tests/README.md](tests/README.md) for reproduction steps and limits. This version has not been verified in a live multiplayer lobby.

## Publishing

Commit the source, project, scripts, docs, and empty configuration example. `.gitignore` excludes build output, third-party DLLs, generated Unity project files, and personal block data. The optional release download is the built `LeaderboardBlock.dll`; game assemblies and local logs are not part of the source package.
