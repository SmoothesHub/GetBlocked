[CmdletBinding()]
param(
    [string]$GamePath = $env:GTAG_PATH,
    [string]$AssemblyPath = (Join-Path $PSScriptRoot 'artifacts/LeaderboardBlock.dll')
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($GamePath)) {
    $GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag'
}
$GamePath = (Resolve-Path -LiteralPath $GamePath).Path
$AssemblyPath = (Resolve-Path -LiteralPath $AssemblyPath).Path
$managed = Join-Path $GamePath 'Gorilla Tag_Data/Managed'
$core = Join-Path $GamePath 'BepInEx/core'
Add-Type -Path (Join-Path $core 'Mono.Cecil.dll')
$resolver = [Mono.Cecil.DefaultAssemblyResolver]::new()
$resolver.AddSearchDirectory($managed)
$resolver.AddSearchDirectory($core)
$options = [Mono.Cecil.ReaderParameters]::new()
$options.AssemblyResolver = $resolver
$assembly = $null
$gameAssembly = $null
try {
    $assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($AssemblyPath, $options)
    $count = 0
    foreach ($member in $assembly.MainModule.GetMemberReferences()) {
        if ($null -eq $member.Resolve()) { throw "Unresolved reference: $($member.FullName)" }
        $count++
    }
    $forbidden = @($assembly.MainModule.GetMemberReferences() | Where-Object {
        $_.Name -match 'SendRPC|ReportPlayer|ReportMute|SendReport|Disconnect|RaiseEvent|NetDestroy|KickPlayer|BanPlayer'
    })
    if ($forbidden.Count -gt 0) {
        throw "Unexpected network or moderation reference: $($forbidden.FullName)"
    }
    $gameAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $managed 'Assembly-CSharp.dll'), $options)
    $targets = @{
        GorillaPlayerScoreboardLine = @('InitializeLine', 'UpdateLine', 'ResetData', 'PressButton')
        GorillaPlayerLineButton = @('Click')
        RigContainer = @('SetMuted', 'RefreshVoiceChat')
        VRRig = @('LocalUpdateCosmeticsWithTryon', 'SetCosmeticsActive')
        'GorillaNetworking.CosmeticItemRegistry' = @('InitializeCosmetic')
        TransferrableObject = @('SetTargetRig', 'OnSpawn', 'OnDespawn')
    }
    $targetCount = 0
    foreach ($typeName in $targets.Keys) {
        $type = $gameAssembly.MainModule.GetType($typeName)
        if ($null -eq $type) { throw "Missing patch type: $typeName" }
        foreach ($methodName in $targets[$typeName]) {
            $methods = @($type.Methods | Where-Object Name -eq $methodName)
            if ($methods.Count -ne 1) { throw "Ambiguous or missing patch target: $typeName.$methodName" }
            if (-not $methods[0].HasBody) { throw "Patch target has no managed body: $typeName.$methodName" }
            $targetCount++
        }
    }
    Write-Output "Resolved $count member references and $targetCount Harmony targets against the installed game."
    Write-Output 'No matching network or moderation member references were found.'
}
finally {
    if ($null -ne $gameAssembly) { $gameAssembly.Dispose() }
    if ($null -ne $assembly) { $assembly.Dispose() }
    $resolver.Dispose()
}
Get-FileHash -Algorithm SHA256 -LiteralPath $AssemblyPath | Select-Object Algorithm, Hash
