[CmdletBinding()]
param([string]$GamePath = $env:GTAG_PATH)

$ErrorActionPreference = 'Stop'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'Install a .NET SDK and make sure dotnet is on PATH.'
}
$buildArgs = @('build', (Join-Path $PSScriptRoot 'LeaderboardBlock.csproj'), '-c', 'Release', '--nologo')
if (-not [string]::IsNullOrWhiteSpace($GamePath)) {
    $resolvedGame = (Resolve-Path -LiteralPath $GamePath).Path
    $buildArgs += "-p:GamePath=$resolvedGame"
}
& dotnet @buildArgs
if ($LASTEXITCODE -ne 0) { throw 'Build failed. See the compiler output above.' }
Get-Item -LiteralPath (Join-Path $PSScriptRoot 'artifacts/LeaderboardBlock.dll') |
    Select-Object FullName, Length
